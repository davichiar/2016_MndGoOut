var express = require("express"),
	mysql = require("mysql"),
	formidable = require("formidable");


var app = express();

var connection = mysql.createConnection({
	host	: "localhost",
	query	: {pool : true },
	user	: "root",
	password: "0000",
	database: "app"
});

const ACC = "account"; //account table name CONSTANT
const VAC = "vac_log"; //vac_log(vacation log) table name CONSTANT
const PER = "personal"; //personal(personal data) table name CONSTANT


//-------------------ACCOUNT PART----------------------

//Register Account: distribute input data and insert into accout/personal table
app.post("/acc/reg",function(req,res){
	console.log("account register request accept");
	var form = new formidable.IncomingForm();
	var body = {};

	form.on("field", function(name,value){
		body[name] = value;
	});

	form.on("end", function(fields, files){
		console.log(body);
		//insert into accout table
		var sql = "INSERT INTO " + ACC +
					" (`soldier_id`, `id`, `pass`)" +
					" VALUES(?,?,?);";
		var args = [body.soldier_id, body.id, body.pass];
		connection.query(sql, args, function(err, results, fields){
			if(err){
				res.sendStatus(500);
				console.log(err);
				return;
			}
		});

		//insert into personal table
		//personal table is changed frequently, so "REPLACE" not "INSERT"
		var sql = "REPLACE INTO " + PER +
					" (`soldier_id`, `group`, `name`, `level`)" +
					" VALUES(?,?,?,?);";
		var args = [body.soldier_id, body.group, body.name, body.level];


		connection.query(sql, args, function(err, results, fields){
			if(err){
				res.sendStatus(500);
				console.log(err);
				return;
			}
			res.sendStatus(200);
		});
	});

	form.parse(req);
});

//Modify Account: distribute input data and update accout/personal table
app.post("/acc/mod",function(req,res){
	console.log("account modify request accept");
	var form = new formidable.IncomingForm();
	var body = {};

	form.on("field", function(name,value){
		body[name] = value;
	});

	form.on("end", function(fields, files){
		//update accout table
		var sql = "UPDATE " + ACC +
					" SET pass = ? WHERE soldier_id = ?";

		var args = [body.pass,body.soldier_id];

		connection.query(sql, args, function(err, results, fields){
			if(err){
				res.sendStatus(500);
				console.log(err);
				return;
			}
		});

		//update personal table
		var sql = "UPDATE " + PER +
					" SET group = ?, name = ?, level = ? WHERE soldier_id = ?;";
		var args = [body.group, body.name, body.level, body.soldier_id];
		connection.query(sql, args, function(err, results, fields){
			if(err){
				res.sendStatus(500);
				console.log(err);
				return;
			}
			res.sendStatus(200);
		});
	});

	form.parse(req);
});


//Delete Account: using solder_id, delete accout/personal table"s record
app.post("/acc/del",function(req,res){
	console.log("account delete request accept");
	var form = new formidable.IncomingForm();
	var body = {};

	form.on("field", function(name,value){
		body[name] = value;
	});

	form.on("end", function(fields, files){
		//delete accout table"s record
		var sql = "DELETE FROM " + ACC +
					" WHERE `soldier_id` = ?";
		var args = [body.soldier_id];
		connection.query(sql, args, function(err, results, fields){
			if(err){
				res.sendStatus(500);
				console.log(err);
				return;
			}
		});

		//delete personal table"s record
		var sql = "DELETE FROM " + PER +
					" WHERE `soldier_id` = ?";
		var args = [body.soldier_id];
		connection.query(sql, args, function(err, results, fields){
			if(err){
				res.sendStatus(500);
				console.log(err);
				return;
			}
			res.sendStatus(200);
		});
	});

	form.parse(req);
});

//------------------------------------------------------------




//-------------------VACATION LOG PART----------------------

//Register VACATION LOG: distribute input data and insert into vac_log/personal table
app.post("/vac/reg",function(req,res){
	console.log("vac_log register request accept");
	var form = new formidable.IncomingForm();
	var body = {};

	form.on("field", function(name,value){
		body[name] = value;
	});

	form.on("end", function(fields, files){
		//insert into vac_log table
		var sql = "INSERT INTO " + VAC +
					" (`soldier_id`, `start_date`, `end_date`, `destination`)" +
					" VALUES(?,?,?,?);";
		var args = [body.soldier_id, body.start_date, body.end_date, body.destination];
		connection.query(sql, args, function(err, results, fields){
			if(err){
				res.sendStatus(500);
				console.log(err);
				return;
			}
		});

		//insert into personal table
		var sql = "REPLACE INTO " + PER +
					" (`soldier_id`, `group`, `name`, `level`, `phone`)" +
					" VALUES(?,?,?,?,?);";
		var args = [body.soldier_id, body.group, body.name, body.level, body.phone];
		connection.query(sql, args, function(err, results, fields){
			if(err){
				res.sendStatus(500);
				console.log(err);
				return;
			}
			res.sendStatus(200);
		});
	});

	form.parse(req);
});

//Modify VACATION LOG: distribute input data and update vac_log/personal table
app.post("/vac/mod",function(req,res){
	console.log("vac_log modify request accept");
	var form = new formidable.IncomingForm();
	var body = {};

	form.on("field", function(name,value){
		body[name] = value;
	});

	form.on("end", function(fields, files){
		//update vac_log table
		var sql = "UPDATE " + VAC +
					" SET `start_date` = ?, `end_date` = ?, `destination` = ? WHERE `soldier_id` = ?";

		var args = [body.start_date, body.end_date, body.destination, body.soldier_id];

		connection.query(sql, args, function(err, results, fields){
			if(err){
				res.sendStatus(500);
				console.log(err);
				return;
			}
		});

		//update personal table
		var sql = "UPDATE " + PER +
					" SET `group` = ?, `name` = ?, `level` = ?, `phone` = ? WHERE `soldier_id` = ?;";
		var args = [body.group, body.name, body.level, body.phone, body.soldier_id];
		connection.query(sql, args, function(err, results, fields){
			if(err){
				res.sendStatus(500);
				console.log(err);
				return;
			}
			res.sendStatus(200);
		});
	});

	form.parse(req);
});


//Delete VACATION LOG: using solder_id, delete vac_log table"s record
app.post("/vac/del",function(req,res){
	console.log("vac_log delete request accept");
	var form = new formidable.IncomingForm();
	var body = {};

	form.on("field", function(name,value){
		body[name] = value;
	});

	form.on("end", function(fields, files){
		//delete accout table"s record
		var sql = "DELETE FROM " + VAC +
					" WHERE `soldier_id` = ?";
		var args = [body.soldier_id];
		connection.query(sql, args, function(err, results, fields){
			if(err){
				res.sendStatus(500);
				console.log(err);
				return;
			}
			res.sendStatus(200);
		});

	});

	form.parse(req);
});

//------------------------------------------------------------



//-------------------PERSONAL DATA PART----------------------

//Register Personal Data: insert into personal table
app.post("/per/reg",function(req,res){
	console.log("personal register request accept");
	var form = new formidable.IncomingForm();
	var body = {};

	form.on("field", function(name,value){
		body[name] = value;
	});

	form.on("end", function(fields, files){
		//insert into personal table
		var sql = "REPLACE INTO " + PER +
					" (`soldier_id`, `group`, `name`, `level`, `phone`, `location`)" +
					" VALUES(?,?,?,?,?,?);";
		var args = [body.soldier_id, body.group, body.name, body.level, body.phone, body.location];
		connection.query(sql, args, function(err, results, fields){
			if(err){
				res.sendStatus(500);
				console.log(err);
				return;
			}
			res.sendStatus(200);
		});
	});

	form.parse(req);
});

//Modify Personal Data: update personal table
app.post("/per/mod",function(req,res){
	console.log("personal modify request accept");
	var form = new formidable.IncomingForm();
	var body = {};

	form.on("field", function(name,value){
		body[name] = value;
	});

	form.on("end", function(fields, files){
		//update personal table
		var sql = "UPDATE " + PER +
					" SET `group` = ?, `name` = ?, `level` = ?, `phone` = ?, `location` = ? WHERE `soldier_id` = ?;";
		var args = [body.group, body.name, body.level, body.phone, body.location, body.soldier_id];
		connection.query(sql, args, function(err, results, fields){
			if(err){
				res.sendStatus(500);
				console.log(err);
				return;
			}
			res.sendStatus(200);
		});
	});

	form.parse(req);
});


//Delete Personal Data: using solder_id, delete personal table"s record
app.post("/per/del",function(req,res){
	console.log("personal delete request accept");
	var form = new formidable.IncomingForm();
	var body = {};

	form.on("field", function(name,value){
		body[name] = value;
	});

	form.on("end", function(fields, files){
		//delete personal table"s record
		var sql = "DELETE FROM " + PER +
					" WHERE `soldier_id` = ?;";
		var args = [body.soldier_id];
		connection.query(sql, args, function(err, results, fields){
			if(err){
				res.sendStatus(500);
				console.log(err);
				return;
			}
			res.sendStatus(200);
		});
	});

	form.parse(req);
});

//------------------------------------------------------------


//Login: using input(id,pass), send soldier_id
app.post("/login",function(req,res){
	console.log("login request accept");
	var form = new formidable.IncomingForm();
	var body = {};

	form.on("field", function(name,value){
		body[name] = value;
	});

	form.on("end", function(fields, files){
		var sql = "SELECT `Soldier_id` FROM " + ACC +
					" WHERE `id` = ? AND `pass` = ?;";
		var args = [body.id, body.pass];
		connection.query(sql, args, function(err, results, fields){
			if(err){
				res.sendStatus(500);
				console.log(err);
				return;
			}
			res.sendStatus(200);
		});
	});

	form.parse(req);
});

//Load data about picked date outsider. Using input data(group, date), output corresponding json data.
//OUTPUT FORM : soldier_id, group, name, level,phone,location,start_date,end_date,destination
app.post("/day",function(req,res){
	console.log("day request accept");
	var form = new formidable.IncomingForm();
	var body = {};

	form.on("field", function(name,value){
		body[name] = value;
	});


	form.on("end", function(fields, files){
			
		var sql = "SELECT * FROM " + PER +
					" NATUAL JOIN " + VAC + 
					" WHERE `group` = ? AND `start_date` <= date(?) AND `end_date` >= date(?);";
		var args = [ body.group, body.date, body.date];
		connection.query(sql, args, function(err, results, fields){
			if(err){
				res.sendStatus(500);
				console.log(err);
				return;
			}
			console.log(results);
			res.sendStatus(200);
		});
	});

	form.parse(req);
});


//Login: using input(id,pass), send soldier_id
app.post("/group",function(req,res){
	console.log("group request accept");
	var form = new formidable.IncomingForm();
	var body = {};

	form.on("field", function(name,value){
		body[name] = value;
	});

	form.on("end", function(fields, files){
		var sql = "SELECT `group` FROM " + PER +
					" WHERE `soldier_id` = ?;";
		var args = [body.soldier_id];
		connection.query(sql, args, function(err, results, fields){
			if(err){
				res.sendStatus(500);
				console.log(err);
				return;
			}
			res.sendStatus(200);
		});
	});

	form.parse(req);
});

app.listen(5009);