package com.swcamp.davichiar.calanderplanner;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View.OnClickListener;

import java.net.Inet4Address;

public class LoginActivity extends AppCompatActivity implements OnClickListener
{
    ImageView login_image_view;
    EditText usernameEditText, userpasswordEditText;
    EditText usernameSignup, usernumberSignup, userclassSignup, userroundSignup;
    EditText userpasswordSignup, ruserpasswordSignup;
    TextView forgotButton;
    Button signinButton, signupButton, usersignupButton;

    ViewGroup login_main_Container;
    LinearLayout login_in_Container, login_up_Container;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // 액션바 숨겨주는 함수
        ActionbarHide();

        // LoginActivity 작성 함수
        LoginSetting();
    }

    public void ActionbarHide()
    {
        getSupportActionBar().hide();
        getWindow().setStatusBarColor(Color.parseColor("#667943"));
    }

    public void LoginSetting()
    {
        // 리니어 레이아웃 추가
        login_main_Container = (ViewGroup) findViewById(R.id.login_main_container);
        login_in_Container = (LinearLayout) findViewById(R.id.login_in_container);
        login_up_Container = (LinearLayout) findViewById(R.id.login_up_container);

        // 이미지 뷰에 로고 추가
        login_image_view = (ImageView) findViewById(R.id.login_image_view);
        login_image_view.setImageResource(R.drawable.mnd_mark);

        LayoutInflater layoutInflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        login_in_Container.addView(layoutInflater.inflate(R.layout.activity_signin, login_main_Container, false));
        login_up_Container.addView(layoutInflater.inflate(R.layout.actvity_signup, login_main_Container, false));

        login_image_view.setVisibility(View.VISIBLE);
        login_in_Container.setVisibility(View.VISIBLE);
        login_up_Container.setVisibility(View.GONE);

        // EditText 추가
        usernameEditText = (EditText) findViewById(R.id.usernameEditText);
        userpasswordEditText = (EditText) findViewById(R.id.userpasswordEditText);

        usernameSignup = (EditText) findViewById(R.id.usernameSignup);
        usernumberSignup = (EditText) findViewById(R.id.usernumberSignup);
        userclassSignup = (EditText) findViewById(R.id.userclassSignup);
        userroundSignup = (EditText) findViewById(R.id.userroundSignup);

        userpasswordSignup = (EditText) findViewById(R.id.userpasswordSignup);
        ruserpasswordSignup = (EditText) findViewById(R.id.ruserpasswordSignup);

        ClearEditText();

        signinButton = (Button) findViewById(R.id.signin_button);
        signinButton.setOnClickListener(this);

        signupButton = (Button) findViewById(R.id.signup_button);
        signupButton.setOnClickListener(this);

        usersignupButton = (Button) findViewById(R.id.user_signup_button);
        usersignupButton.setOnClickListener(this);

        forgotButton = (TextView) findViewById(R.id.forgot_button);
        forgotButton.setOnClickListener(this);
    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.signin_button:
                Signin();
                break;

            case R.id.signup_button:
                login_image_view.setVisibility(View.GONE);
                login_in_Container.setVisibility(View.GONE);
                login_up_Container.setVisibility(View.VISIBLE);
                break;

            case R.id.user_signup_button:
                UserSignIn();
                break;
        }
    }

    private void Signin()
    {
        String username = usernameEditText.getText().toString();
        String password = userpasswordEditText.getText().toString();

        if(username.equals(""))
        {
            usernameEditText.setError("이름/군번을 입력해주세요");
            usernameEditText.requestFocus();
        }
        else if(password.equals(""))
        {
            userpasswordEditText.setError("비밀번호를 입력해주세요");
            userpasswordEditText.requestFocus();
        }
        else
        {
            Toast.makeText(getApplicationContext(), "로그인 성공!", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(getApplicationContext(), CalenderActivity.class);
            startActivity(intent);
            finish();
        }
    }

    private void UserSignIn()
    {
        String username = usernameSignup.getText().toString();
        String usernumber = usernumberSignup.getText().toString();
        String userclass = userclassSignup.getText().toString();
        String userround = userroundSignup.getText().toString();
        String password = userpasswordSignup.getText().toString();
        String rpassword = ruserpasswordSignup.getText().toString();

        if(username.equals(""))
        {
            usernameSignup.setError("이름을 입력해주세요");
            usernameSignup.requestFocus();
        }
        else if(usernumber.equals(""))
        {
            usernumberSignup.setError("군번을 입력해주세요");
            usernumberSignup.requestFocus();
        }
        else if(userclass.equals(""))
        {
            userclassSignup.setError("계급을 입력해주세요");
            userclassSignup.requestFocus();
        }
        else if(userround.equals(""))
        {
            userroundSignup.setError("소속을 입력해주세요");
            userroundSignup.requestFocus();
        }
        else if(password.equals(""))
        {
            userpasswordSignup.setError("비밀번호를 입력해주세요");
            userpasswordSignup.requestFocus();
        }
        else if(rpassword.equals(""))
        {
            ruserpasswordSignup.setError("비밀번호를 입력해주세요");
            ruserpasswordSignup.requestFocus();
        }
        else if(!password.equals(rpassword))
        {
            ruserpasswordSignup.setError("잘못된 비밀번호 입니다");
            ruserpasswordSignup.requestFocus();
        }
        else
        {
            Toast.makeText(getApplicationContext(), "회원가입 성공!", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(getApplicationContext(), CalenderActivity.class);
            startActivity(intent);
            finish();
        }
    }
    public void ClearEditText()
    {
        usernameEditText.setText(null);
        userpasswordEditText.setText(null);
        usernameSignup.setText(null);
        usernumberSignup.setText(null);
        userclassSignup.setText(null);
        userroundSignup.setText(null);
        userpasswordSignup.setText(null);
        ruserpasswordSignup.setText(null);
    }
}
