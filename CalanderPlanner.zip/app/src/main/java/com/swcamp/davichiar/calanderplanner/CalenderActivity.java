package com.swcamp.davichiar.calanderplanner;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.DatePicker;
import android.widget.LinearLayout;
import android.widget.NumberPicker;
import android.widget.TextView;
import android.widget.Toast;

import com.nightonke.boommenu.BoomMenuButton;
import com.nightonke.boommenu.Types.BoomType;
import com.nightonke.boommenu.Types.ButtonType;
import com.nightonke.boommenu.Types.ClickEffectType;
import com.nightonke.boommenu.Types.DimType;
import com.nightonke.boommenu.Types.OrderType;
import com.nightonke.boommenu.Types.PlaceType;
import com.nightonke.boommenu.Util;
import com.prolificinteractive.materialcalendarview.CalendarDay;
import com.prolificinteractive.materialcalendarview.CalendarMode;
import com.prolificinteractive.materialcalendarview.MaterialCalendarView;
import com.prolificinteractive.materialcalendarview.OnDateSelectedListener;
import com.prolificinteractive.materialcalendarview.OnMonthChangedListener;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

import java.util.Calendar;
import java.util.Random;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnCheckedChanged;
import butterknife.OnClick;

public class CalenderActivity extends AppCompatActivity implements BoomMenuButton.OnSubButtonClickListener, OnDateSelectedListener, OnMonthChangedListener {

    // 메뉴바 설정
    private BoomMenuButton boomMenuButton;
    private BoomMenuButton boomMenuButtonInActionBar;
    private BoomMenuButton boomInfo;

    private Context mContext;
    private View mCustomView;

    private boolean isInit = false;

    private static final DateFormat FORMATTER = SimpleDateFormat.getDateInstance();

    @Bind(R.id.calendarView)
    MaterialCalendarView widget;

    @Bind(R.id.textView)
    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calender);
        ButterKnife.bind(this);

        // 액션바 숨겨주는 함수
        ActionbarHide();

        // 메뉴바 설정
        CustomMenu();

        // 캘린더설정
        CalenderMenu();
    }

    // 액션바 설정
    public void ActionbarHide()
    {
        getSupportActionBar().hide();
        getWindow().setStatusBarColor(Color.parseColor("#667943"));
    }

    // 메뉴바 설정
    public void CustomMenu()
    {
        mContext = this;

        ActionBar mActionBar = getSupportActionBar();
        mActionBar.setDisplayShowHomeEnabled(false);
        mActionBar.setDisplayShowTitleEnabled(false);
        LayoutInflater mInflater = LayoutInflater.from(this);

        mCustomView = mInflater.inflate(R.layout.custom_actionbar, null);
        TextView mTitleTextView = (TextView) mCustomView.findViewById(R.id.title_text);
        mTitleTextView.setText(R.string.app_name);

        boomMenuButtonInActionBar = (BoomMenuButton) mCustomView.findViewById(R.id.boom);

        mActionBar.setCustomView(mCustomView);
        mActionBar.setDisplayShowCustomEnabled(true);

        ((Toolbar) mCustomView.getParent()).setContentInsetsAbsolute(0,0);

        boomMenuButton = (BoomMenuButton)findViewById(R.id.boom);

        boomInfo = (BoomMenuButton)mCustomView.findViewById(R.id.info);

        initViews();
    }
    @Override
    public void onWindowFocusChanged(boolean hasFocus)
    {
        super.onWindowFocusChanged(hasFocus);

        if (!isInit) {
            initBoom();
        }
        isInit = true;
    }
    private void initBoom() {
        int number = 9;

        Drawable[] drawables = new Drawable[number];
        int[] drawablesResource = new int[]
                {
                R.drawable.mark,
                R.drawable.refresh,
                R.drawable.copy,
                R.drawable.heart,
                R.drawable.info,
                R.drawable.like,
                R.drawable.record,
                R.drawable.search,
                R.drawable.settings
        };
        for (int i = 0; i < number; i++)
            drawables[i] = ContextCompat.getDrawable(mContext, drawablesResource[i]);

        String[] STRINGS = new String[]{
                "Mark",
                "Refresh",
                "Copy",
                "Heart",
                "Info",
                "Like",
                "Record",
                "Search",
                "Settings"
        };
        String[] strings = new String[number];
        for (int i = 0; i < number; i++)
            strings[i] = STRINGS[i];

        int[][] colors = new int[number][2];

        colors[0][1] = Color.parseColor("#998A00");
        colors[1][1] = Color.parseColor("#2F9D27");
        colors[2][1] = Color.parseColor("#0054FF");
        colors[3][1] = Color.parseColor("#F15F5F");
        colors[4][1] = Color.parseColor("#997000");
        colors[5][1] = Color.parseColor("#C4B73B");
        colors[6][1] = Color.parseColor("#990085");
        colors[7][1] = Color.parseColor("#476600");
        colors[8][1] = Color.parseColor("#002266");

        for (int i = 0; i < number; i++) {
            colors[i][0] = Util.getInstance().getPressedColor(colors[i][1]);
        }

        // Now with Builder, you can init BMB more convenient
        new BoomMenuButton.Builder()
                .subButtons(drawables, colors, strings)
                .button(ButtonType.CIRCLE)
                .boom(BoomType.HORIZONTAL_THROW)
                .place(getPlaceType())
                .boomButtonShadow(Util.getInstance().dp2px(2), Util.getInstance().dp2px(2))
                .subButtonsShadow(Util.getInstance().dp2px(2), Util.getInstance().dp2px(2))
                .onSubButtonClick(this)
                .init(boomMenuButton);

        // Now with Builder, you can init BMB more convenient
        new BoomMenuButton.Builder()
                .subButtons(drawables, colors, strings)
                .button(ButtonType.CIRCLE)
                .boom(BoomType.HORIZONTAL_THROW)
                .place(getPlaceType())
                .subButtonsShadow(Util.getInstance().dp2px(2), Util.getInstance().dp2px(2))
                .onSubButtonClick(this)
                .dim(DimType.DIM_0)
                .init(boomMenuButtonInActionBar);
    }
    private void initViews()
    {
        boomMenuButton.setDuration(501 * 500);
        boomMenuButtonInActionBar.setDuration(501 * 500);
        boomMenuButton.setDelay(101 * 100);
        boomMenuButtonInActionBar.setDelay(101 * 100);

        boomMenuButton.setRotateDegree(0);
        boomMenuButtonInActionBar.setRotateDegree(0);

        boomMenuButton.setAutoDismiss(true);
        boomMenuButtonInActionBar.setAutoDismiss(true);

        boomMenuButton.setShowOrderType(OrderType.DEFAULT);
        boomMenuButtonInActionBar.setShowOrderType(OrderType.DEFAULT);
        boomMenuButton.setHideOrderType(OrderType.DEFAULT);
        boomMenuButtonInActionBar.setHideOrderType(OrderType.DEFAULT);

        boomMenuButton.setClickEffectType(ClickEffectType.RIPPLE);
        boomMenuButtonInActionBar.setClickEffectType(ClickEffectType.RIPPLE);
        boomInfo.setClickEffectType(ClickEffectType.RIPPLE);
    }
    private PlaceType getPlaceType() { return PlaceType.CIRCLE_9_1; }
    @Override
    public void onClick(int buttonIndex)
    {
        showDatePickerDialog(this, widget.getSelectedDate(), new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                widget.setSelectedDate(CalendarDay.from(year, monthOfYear, dayOfMonth));
            }
        });
    }
    @Override
    public void onBackPressed() {
        if (boomMenuButton.isClosed()
                && boomMenuButtonInActionBar.isClosed()
                && boomInfo.isClosed()) {
            super.onBackPressed();
        } else {
            boomMenuButton.dismiss();
            boomMenuButtonInActionBar.dismiss();
            boomInfo.dismiss();
        }
    }

    public void CalenderMenu()
    {
        widget.setOnDateChangedListener(this);
        widget.setOnMonthChangedListener(this);

        //Setup initial text
        textView.setText(getSelectedDatesString());
    }
    @Override
    public void onDateSelected(@NonNull MaterialCalendarView widget, @Nullable CalendarDay date, boolean selected) {
        textView.setText(getSelectedDatesString());
    }

    @Override
    public void onMonthChanged(MaterialCalendarView widget, CalendarDay date) {
        //noinspection ConstantConditions
        getSupportActionBar().setTitle(FORMATTER.format(date.getDate()));
    }

    private String getSelectedDatesString() {
        CalendarDay date = widget.getSelectedDate();
        if (date == null) {
            return "No Selection";
        }
        return FORMATTER.format(date.getDate());
    }

    public static void showDatePickerDialog(Context context, CalendarDay day,
                                            DatePickerDialog.OnDateSetListener callback) {
        if (day == null) {
            day = CalendarDay.today();
        }
        DatePickerDialog dialog = new DatePickerDialog(
                context, 0, callback, day.getYear(), day.getMonth(), day.getDay()
        );
        dialog.show();
    }

}